





List<String>Resimler=[
  "https://i.pinimg.com/originals/1a/8d/de/1a8dde46339c4c45cbae159ba6384dcc.gif",
 "http://www.internethaber.com/images/other/bayram-mesajlari-yeni.gif",
  "https://i0.wp.com/www.pekguzelsozler.com/wp-content/uploads/2018/06/2018-Ramazan-Bayram%C4%B1-Mesajlar%C4%B1-6.jpg?w=730",
  "https://www.ekovitrin.com/images/upload/1_7.gif",
  "https://im.haberturk.com/2021/05/13/3070516_7e71bdccd28d9152d3d4f9c419748cc3_640x640.jpg",
  "https://i.pinimg.com/originals/ec/3f/b6/ec3fb6e9b9971b93c6869b76adb12e8f.gif",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMqRbwzHtWAnT7_WnHZOUpF0GKbl9Tku8TNSXDRyg0maLS1q8c_Su3P7AG0jNsw-8GH7w&usqp=CAU",
  "https://cokiyiabi.com/wp-content/uploads/2019/06/ramazan-bayrami-mesajlari-2019-22.png",
  "https://i.pinimg.com/originals/16/f6/af/16f6af6c4c414e741f05e2c92b8307aa.gif",
  "https://i2.cnnturk.com/i/cnnturk/75/1200x0/609a8366b57f1507f8947f12.jpg",
  "http://www.internethaber.com/images/other/bayram-mesajlari-yeni.gif",
  "https://i.pinimg.com/originals/1b/2d/38/1b2d3845116962b8e76f0544aa61cf18.jpg",
  "https://3.bp.blogspot.com/-PI-e2Lyb1P4/WU6nKuuNL1I/AAAAAAAClCM/3eJHGXSgau0otT-kQrNc8y1DJjDPErF2wCLcBGAs/s1600/mektup406.gif",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRNICTbkccf1GYAZ3QdLgD0Lp_PVeTZQxZbuuOGU864Yiu15qrMU3N7Zi2VBdLgHpvos0&usqp=CAU",
 "https://i.pinimg.com/originals/1e/db/b7/1edbb7e174c576a1666bef3ab88cbed5.gif",
  "https://i.pinimg.com/736x/ea/60/ef/ea60ef45a06bd72353d958d98feb528a.jpg",
  "https://yunti.files.wordpress.com/2016/07/ramazan_bayram.gif",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTU-81DNu7wDBEi6KHsBln6wPBCCa2R3Hel2uDz_mR6TwTgojLLQn4GurUCRuzZ1ff8Hj4&usqp=CAU",
  "https://www.kamubulteni.com/images/upload/2_3.gif",
  "https://i.sozcu.com.tr/wp-content/uploads/2020/05/22/seker-bayrami-mesajlari.jpg",
  "https://yunti.files.wordpress.com/2018/06/ramazan_bayram_01_tam35-blogspot-com.gif",
  "https://www.cumhuriyet.com.tr/Archive/2014/7/28/99521_cover.jpeg",
  "http://imgs.star.com.tr/imgsdisk/2016/07/02/020720161025324351295_3.jpg",
  "https://i.pinimg.com/originals/60/58/69/6058692b6caa06cf87358c6d599bc278.gif",
  "https://i0.wp.com/www.saglikhaberci.com/wp-content/uploads/2019/06/%C5%9Feker-bayram%C4%B1.jpg?fit=650%2C360&ssl=1",
  "https://i.pinimg.com/originals/8b/20/ce/8b20cec2748ccc429152577e67b928df.gif",
  "https://i.pinimg.com/736x/3a/8e/ec/3a8eecfbd5ca1f8a423fd3231ffe7e61.jpg",
  "https://3.bp.blogspot.com/-RhERYLFyrI4/XT36bPf33uI/AAAAAAAEUbc/ilAIpF8txEIR6CbP47tNYSc0j0VEdXj_QCK4BGAYYCw/s1600/b10.gif",
  "https://www.detayhaberler.com/images/galeri/2021/05/1620842625_57.jpg",
  "https://www.haberler23.com/wp-content/uploads/2021/05/resimli-ramazan-bayrami-mesajlari-122-1-640x360.jpg",
  "https://www.risalehaber.com/d/other/ramazan-bayram-mesajlari-anlamli.jpg",
 "https://www.kamubulteni.com/images/upload/2_3.gif",
  "https://foto.haberler.com/haber/2019/06/03/ramazan-bayrami-mesajlari-2019-en-guzel-resimli-12112619_6999_o.jpg",
  "https://www.siverekgenclik.com/images/haberler/1/11344.jpg",
  "https://i.pinimg.com/originals/ee/9d/6d/ee9d6d2163936ab2c44b080120bf346f.jpg",
  "https://i.pinimg.com/originals/ac/bc/60/acbc60197ed20c253b02dab87e57a9d5.png",
  "https://im.haberturk.com/2018/06/14/2015956_ad328f53e92c4f195b0c105d183f8bf9_640x640.jpg",
  "https://sozleralemi.com/wp-content/uploads/2017/12/kurban-bayrami-mesajlari-1.jpg",
  "https://im.haberturk.com/2019/06/05/96c6be34a9a3baf5f903d5bc38955d24_640x640.jpg",
  "https://2.bp.blogspot.com/-j9KeRlrh44E/V3ZcfEY5CWI/AAAAAAAAIAI/4qgFqUNUpWcnnalGnshRqNLx8vx4aAaugCLcB/s1600/PicsArt_06-28-03.47.09.jpg",
  "https://i.pinimg.com/originals/aa/47/5c/aa475ce989b46bf96b0849cd56e3ca36.jpg",
  "https://www.pekguzelsozler.com/wp-content/uploads/2021/05/2021-Ramazan-Bayram%C4%B1-Mesajlar%C4%B1.jpg",
  "https://assets.dogannet.tv/img/75/740x0/609c273566a97cc9e4992e21",
  "https://iasbh.tmgrup.com.tr/1dd75e/650/344/0/0/650/341?u=https://isbh.tmgrup.com.tr/sbh/2021/05/13/bayram-mesajlari-ve-sozleri-2021-en-guzel-anlamli-huzur-dolu-ayetli-duali-ve-resimli-ramazan-bayram-kutlama-mesajlari-1620889990365.jpg",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3cd0VJ68H0jDPvsXnGBneGDhIKhm0zN8tzFbmQXVxFVPCGOa1bLmYIDKyekZz8TGYZfU&usqp=CAU",
  "https://im.haberturk.com/2020/05/24/2689946_7e3fe630d9299b843b9e77a4b915c0dc_640x640.jpg",
  "https://www.projemlak.com/images/haberler/bayram-mesajlari-en--92fc2e1f986bc8fea03c.jpg",
  "https://www.pekguzelsozler.com/wp-content/uploads/2017/06/Resimli-Ramazan-Bayram%C4%B1-Kutlama-Mesajlar%C4%B1-7.jpg",
  "http://mersin.temad.org/wp-content/uploads/sites/68/2020/05/ramazan-bayram%C4%B12.jpg",
  "https://www.huzursayfasi.com/images/editor/images/ramazan-bayram%C4%B1-mesajlar%C4%B1.jpg",
  "https://iasbh.tmgrup.com.tr/584dbb/650/344/0/1/880/464?u=https://isbh.tmgrup.com.tr/sbh/2021/05/11/ramazan-bayrami-mesajlari-ve-tebrik-sozleri-2021-en-guzel-anlamli-kisa-yeni-ve-resimli-bayram-mesajlari-secenekleri-1620744974216.jpg",

];

class TumMesajlar {
  String? kisaMesaj;

  TumMesajlar({required this.kisaMesaj});
}

List<TumMesajlar> MesajlariListele = [
 TumMesajlar(kisaMesaj: 'Heyecan ve özlemle beklenen kutsal Ramazan Bayramı geldi, hoş geldi! Mübarek bayram ulusumuza sağlık, huzur, mutluluk, bolluk ve bereket getirsin. Hayırlı bayramlar'),
  TumMesajlar(kisaMesaj: 'Hayat nefes aldığımız kadardır, gerçek olan güzellikler yaşandıkça anlaşılır bu güzel günde birlikte yaşamanın ümidi ile Ramazan Bayramınızı kutlarız'),
  TumMesajlar(kisaMesaj: 'Birlikte geçen mutlu günlere özlem duyduğumuz bu bayramı en güzel şekilde geçirmeniz dileğiyle. Hayırlı bayramlar…'),
  TumMesajlar(kisaMesaj: 'Dilden gelen gönüldense, dokunur başka gönüllere… En içten dileklerimle bayramını kutlar, bu Ramazan bayramının hayırlara vesile olmasını dilerim.'),
  TumMesajlar(kisaMesaj: 'Ne mesafeler, ne imkansızlıklar bayramın coşkusuna gem vuramaz. Gönüller bir oldukça mesafeler kısalır, imkan kapıları sonuna kadar açılır. Ramazan Bayramınız kutlu olsun'),
  TumMesajlar(kisaMesaj: 'Ne şanslıymışız, dostlarla olduğumuz günlerde. Bir kez daha öğrendik sağlık en büyük şükür sebebiymiş. Dilerim son olsun… İyi bayramlar.'),
  TumMesajlar(kisaMesaj: "Bayramın dili yok. Olsaydı insanoğluna 'barışın, affedin ve sevin' derdi. Siz, bu sessiz çağrıya kulak verin. Bayramınız kutlu olsun"),
  TumMesajlar(kisaMesaj: 'Küslerin barıştığı, sevenlerin bir araya geldiği, rahmet ve şefkat dolu günlerin en değerlilerinden olan Ramazan Bayramınız kutlu olsun'),
  TumMesajlar(
      kisaMesaj: 'Küskünlerin barıştığı, sevenlerin bir araya geldiği, '
          'rahmetle ve şefkatle dolu günlerin en değerlilerinden olan Ramazan Bayramınız kutlu olsun.'),
  TumMesajlar(
      kisaMesaj:
      'Mübarek Ramazan Bayramı sana ve ailene bol mutluluk bol huzur ve refah bir hayat getirsin, '
          'bu Ramazan bayramının güzelliğini ve '
          'bereketini evine getirsin kalbine iman nefesine güç versin. Ramazan Bayramınız Mübarek Olsun.'),
  TumMesajlar(kisaMesaj: 'Mübarek Ramazan Bayramını sevdiklerinizle beraber sağlıklı ve huzur içinde'
      ' geçirmenizi dileriz. Bayram tüm insanlığa hayırlı olsun'),
  TumMesajlar(kisaMesaj: "Kainatın yaratıcısı ve alemlerin Rabbi yüce Allah'a sonsuz şükürler olsun."
      "Ramazan Bayramı bereketiyle, bolluğuyla gelsin, tüm insanlık için hayırlara vesile olsun."),
  TumMesajlar(kisaMesaj: 'Mübarek Ramazan Bayramınızı tebrik eder hayırlara vesile olmasını dileriz.'
      ' Bu hayırlı günde dualarınız kabul olsun. Dualarınızı eksik etmeyin'),
  TumMesajlar(kisaMesaj: 'Küskünlerin barıştığı, sevenlerin bir araya geldiği, '
      'rahmetle ve şefkatle dolu günlerin en değerlilerinden olan Ramazan Bayramınız kutlu olsun.'),
  TumMesajlar(kisaMesaj: 'Çılgınca esen rüzgar, kavurucu güneşli terleten günler, yıldızlarla dolu bir dünyadır bayramlar.'
      'Ramazan Bayramınız Mübarek olsun her şey istediğiniz gibi olsun inşallah'),
  TumMesajlar(kisaMesaj: 'Mübarek Ramazan Bayramı sana ve ailene bol mutluluk bol huzur ve refah bir hayat getirsin,'
      ' bu Ramazan bayramının güzelliğini ve bereketini evine getirsin kalbine iman nefesine güç versin.'
      'Ramazan Bayramınız Mübarek Olsun.'),
  TumMesajlar(kisaMesaj: 'Bugün dualarınızı her zamankinden daha çok yapın,'
      ' koruyucu meleklerini avuçlarınızın içine çiçekler döksün, kalplerinize bedeninize ilham versin. '
      'Bayramları en hayırlı şekilde geçirmeyi nasip etsin bizlere. Ramazan bayramınızı kutlarım.'),
  TumMesajlar(kisaMesaj: 'Sevinç ve huzur dolu bir umutla geldi Ramazan Bayramı. Bu güzel ayın mübarek bayramı bizlere mutluluk, huzur,'
      ' güzellikler nasip etsin. Bütün müslümanlara Hayırlı Ramazan Bayramı diliyorum.'),
  TumMesajlar(kisaMesaj: 'Her ilkbaharda gelinciklerin en güzel başlangıçları müjdelemesi gibi, bu '
      'bayramın da sana ve ailene mutluluk ve neşe getirmesini diliyorum.İyi Bayramlar'),
  TumMesajlar(kisaMesaj: 'Bu hayırlı günlerin sevgi, saygı, yardımlaşma ve dayanışmanın ön plana çıktığı, manevi duygularımızı bir nebze olsun terbiye etmeye ve güzel davranışlar '
      'göstermemize vesile olmasını dilerim. Ramazan Bayramınız mübarek olsun.'),
  TumMesajlar(kisaMesaj: 'Kainatın yaratıcısı ve müslüman aleminin Rabbi olan yüce Allah’a sonsuz teşekkürlerimiz olsun! Ramazan Bayramı bereketiyle, bolluğuyla ve sevgisiyle gelsin, herkes için hayırlara vesile olsun. Bayramınız mübarek olsun.'),
  TumMesajlar(kisaMesaj: 'Vesile olalım kardeşliğe ve barışa. Tat alalım, varalım yüce Allah"a. Erişelim birlikte nice bayramlara ve mutluluğa. Mübarek Ramazan Bayramınızı en içten dileklerimle kutlarım.'),
  TumMesajlar(kisaMesaj: "Bir avuç dua, bir kucak sevgi, sıcak bir mesaj mesafeleri kapatır, gönülleri birleştirir. Kalbiniz nur, eviniz huzur dolsun. Ramazan Bayramınız bereketli olsun"),
  TumMesajlar(kisaMesaj: "Sevdiklerinizle bir arada, sağlık, huzur ve mutluluk dolu nice bayramlar geçirmeniz dileklerimle birlikte, Ramazan Bayramı'nızı tebrik ederim."),
  TumMesajlar(kisaMesaj: 'Her gününüzün bayram coşkusu ve mutluluğu içinde sevdiklerinizle birlikte geçmesini diler; selam, sevgi ve saygılarımı sunarım.'),
  TumMesajlar(kisaMesaj: 'Bayramlar, dargınlıkların unutulduğu, küslerin barıştığı, kardeşçe kucaklaştıkları günlerdir. Ramazan Bayramınız mübarek olsun'),
  TumMesajlar(kisaMesaj: 'Bu mutlu günde, güzel insanlara, özel insanlara, hani vazgeçemediklerimize, sevgilerimizi, saygılarımızı, dualarımızı gönderiyoruz. Her gününüz bir bayram olsun...'),
  TumMesajlar(kisaMesaj: 'Damağınızı, ruhunuzu ve çevrenizi tatlandıran, mutlu, umutlu, bereketli bir bayram dileriz.'),
  TumMesajlar(kisaMesaj: " Vesile olalım kardeşliğe ve barışa. Yorulalım hepimiz yarınki uğraşa. Erişelim birlikte nice bayramlara. Mübarek ramazan bayramınızı en içten dileklerimle kutlar; küskünlerin barıştığı, sevenlerin bir araya geldiği bir bayram dilerim"),
  TumMesajlar(kisaMesaj: ' Kardeşliğin doğduğu, sevgilerin birleştiği, belki durgun, belki yorgun, yine de mutlu, yine de umutlu, yine de sevgi dolu nice bayramlara. Ramazan Bayramınızı kutlar, küçüklerin ellerinden, büyüklerin gözlerinden öperim.'),
  TumMesajlar(kisaMesaj: 'Kalpler vardır sevgiyi yaşatmak için, insanlar vardır dostluğu paylaşmak için ve bayramlar vardır sevgi ile kucaklaşmak için. Ramazan Bayramınızı kutlarım.'),
  TumMesajlar(kisaMesaj: 'Ramazan Bayramının güzelliğini ve bereketini yaşadığınız, sevdiklerinizle birlikte nice bayramlar dilerim.'),
];

package com.rmzn.byrm.msj.ramazanbayramimesajlari

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
